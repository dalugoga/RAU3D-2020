﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CloudSelector : MonoBehaviour
{
    VRTK.VRTK_StraightPointerRenderer pointer_renderer;
    VRTK.VRTK_ControllerEvents controller_events;

    GameObject selected_cloud = null;

    public Color old_color;
    public Color new_color = new Color(255 / 255.0f, 61 / 255.0f, 249 / 255.0f);
    public Color selected_color;

    private Vector3 scaleChange = new Vector3(-0.05f, -0.05f, -0.05f);

    public Material default_material;
    public Material selected_material;

    public Material select_tool_material;
    public Material unselect_tool_material;

    GameObject select_bubble;
    MeshRenderer select_bubble_renderer;

    HashSet<int> selected_vertices;
    Vector3[] point_cloud_vertices;

    Vector3 grab_start_pos;

    enum tool_state
    {
        Inactive,
        Select,
        Unselect
    }

    tool_state tool = tool_state.Inactive;

    // Start is called before the first frame update
    void Start()
    {
        pointer_renderer = GameObject.Find("RightControllerScriptAlias").GetComponent<VRTK.VRTK_StraightPointerRenderer>();
        controller_events = GameObject.Find("RightControllerScriptAlias").GetComponent<VRTK.VRTK_ControllerEvents>();
        select_bubble = GameObject.Find("Select Bubble");
        select_bubble_renderer = select_bubble.GetComponent<MeshRenderer>();
        select_bubble_renderer.enabled = false;
        selected_vertices = new HashSet<int>();

        controller_events.TriggerPressed += new VRTK.ControllerInteractionEventHandler(DoTriggerPressed);
        controller_events.ButtonTwoPressed += new VRTK.ControllerInteractionEventHandler(DoButtonTwoPressed);
        controller_events.GripPressed += new VRTK.ControllerInteractionEventHandler(DoGripPressed);
        controller_events.GripReleased += new VRTK.ControllerInteractionEventHandler(DoGripReleased);
    }

    void DoGripPressed(object sender, VRTK.ControllerInteractionEventArgs e)
    {
        grab_start_pos = e.controllerReference.actual.transform.position;
    }

    void DoGripReleased(object sender, VRTK.ControllerInteractionEventArgs e)
    {
        Vector3 end_start_pos = e.controllerReference.actual.transform.position;
        Vector3 translate_vector = end_start_pos - grab_start_pos;

        Mesh mesh = selected_cloud.GetComponent<MeshFilter>().mesh;

        Vector3[] vertices = new Vector3[mesh.vertices.Length];

        for (int i = 0; i < vertices.Length; i++)
        {
            if (selected_vertices.Contains(i))
                vertices[i] = mesh.vertices[i] + translate_vector;
            else
                vertices[i] = mesh.vertices[i];
        }

        mesh.vertices = vertices;
    }

    void DoTriggerPressed(object sender, VRTK.ControllerInteractionEventArgs e)
    {
        if (pointer_renderer.GetDestinationHit().collider != null && pointer_renderer.GetDestinationHit().collider.gameObject.tag == "Point Cloud")
        {
            if (selected_cloud != null && selected_cloud.name == pointer_renderer.GetDestinationHit().collider.gameObject.name)
                UnselectCloud(selected_cloud);
            else
                SelectNewCloud(pointer_renderer.GetDestinationHit().collider.gameObject);
        }
    }

    public void SelectNewCloud(GameObject go)
    {
        if (selected_cloud != null)
            UnselectCloud(selected_cloud);

        selected_cloud = go;
        UpdateColor(selected_cloud, new_color, true);

        go.GetComponent<Renderer>().material = selected_material;
    }

    public void UnselectCloud(GameObject go)
    {
        UpdateColor(go, old_color, false);
        go.GetComponent<Renderer>().material = default_material;
        selected_cloud = null;
    }

    void DoButtonTwoPressed(object sender, VRTK.ControllerInteractionEventArgs e)
    {
        Color paint_color;

        if (tool == tool_state.Inactive)
            return;
        else if (tool == tool_state.Select)
            paint_color = selected_color;
        else
            paint_color = new_color;

        float bubble_radius = select_bubble.GetComponent<SphereCollider>().radius * select_bubble.transform.localScale.x;
        Vector3 bubble_center = select_bubble.GetComponent<Renderer>().bounds.center;

        Mesh mesh = selected_cloud.GetComponent<MeshFilter>().mesh;
        Matrix4x4 localToWorld = selected_cloud.transform.localToWorldMatrix;

        Color[] colors = new Color[mesh.colors.Length];

        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            Vector3 point_world = localToWorld.MultiplyPoint3x4(mesh.vertices[i]);

            if(Vector3.Distance(bubble_center, point_world) < bubble_radius)
            {
                colors[i] = paint_color;
                if (tool == tool_state.Select)
                    selected_vertices.Add(i);
                else
                    selected_vertices.Remove(i);
            }
            else
                colors[i] = mesh.colors[i];
        }

        mesh.colors = colors;
    }



    public void UpdateColor(GameObject go, Color color, bool save_color)
    {
        Mesh mesh = go.GetComponent<MeshFilter>().mesh;

        if (save_color)
            old_color = mesh.colors[0];

        Color[] colors = new Color[mesh.colors.Length];

        for (int i = 0; i < colors.Length; i++)
            colors[i] = color;

        mesh.colors = colors;
    }

    #region Radial Menu

    public void IncreasePointSize()
    {
        selected_material.SetFloat("_PointSize", selected_material.GetFloat("_PointSize") + 0.003f);
    }

    public void DecreasePointSize()
    {
        selected_material.SetFloat("_PointSize", selected_material.GetFloat("_PointSize") - 0.003f);
    }

    public void ShowSurface()
    {
        selected_cloud.transform.GetChild(0).gameObject.SetActive(!selected_cloud.transform.GetChild(0).gameObject.activeSelf);
    }

    public void SelectTool()
    {
        if (!select_bubble_renderer.enabled)
        {
            select_bubble_renderer.enabled = true;
            tool = tool_state.Select;
        }
        else if (tool == tool_state.Select)
        {
            select_bubble_renderer.enabled = false;
            tool = tool_state.Inactive;
        }
        else if (tool == tool_state.Unselect)
            tool = tool_state.Select;

        select_bubble.GetComponent<Renderer>().material = select_tool_material;
    }

    public void UnSelectTool()
    {
        if (!select_bubble_renderer.enabled)
        {
            select_bubble_renderer.enabled = true;
            tool = tool_state.Unselect;
        }
        else if (tool == tool_state.Unselect)
        {
            select_bubble_renderer.enabled = false;
            tool = tool_state.Inactive;
        }
        else if (tool == tool_state.Select)
            tool = tool_state.Unselect;

        select_bubble.GetComponent<Renderer>().material = unselect_tool_material;
    }

    public void SizeUp()
    {
        select_bubble.transform.localScale -= scaleChange;
    }

    public void SizeDown()
    {
        select_bubble.transform.localScale += scaleChange;
    }

    #endregion
}
